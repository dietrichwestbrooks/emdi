declare module "browser-xml2js" {
    function parseString(xml: string, callback: (error: any, json: any) => void ): void;
}
