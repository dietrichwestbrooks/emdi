# emdi

[![styled with prettier](https://img.shields.io/badge/styled_with-prettier-ff69b4.svg)](https://github.com/prettier/prettier)

## Fetch dependencies
```
npm install emdijs --save
```
